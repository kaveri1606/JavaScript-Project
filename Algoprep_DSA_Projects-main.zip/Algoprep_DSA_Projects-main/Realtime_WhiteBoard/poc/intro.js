// print
// console.log("Hello algopeeps:)");
// // variables
// let i = 0;
// i = 2.1;
// i = "Hello";
// i = true;
// console.log(i);


// JS -> top to bottom, left to right
// console.log("Hello algopeeps:)");
// let a;
// // default value of a is undefined
// console.log("a is: ", a);
// Javascript is a dynamically typed language
// numbers -> maths numbers
// a=10;
// a=12;
// console.log("a is: ", a);
// console.log(5/3);
// strings 
// let str = "Hello";
// let str1 = 'Hello';
// console.log(str);
// console.log(str1);
// booelan, null
// str=null
// console.log(str);

// let number = 10;
// if (number % 2 == 0) {
//     console.log("Even");
// } else {
//     console.log("Odd");
// }
// loops 
// for, while, do-while

// for (let i = 0; i < 5; i++) {
//     console.log(i);
// }

// function sayhi() {
//     console.log("Hi");
// }
// sayhi();








