# formula Explained

## constraints
* Grid 
  * columns : 26
  * rows :100

* Formula -> 
  * syntax : they only have opening and closing brace and space between each token
  * set, update : formula bar 

## Observations
**Possible source of data for a cell**
* user defined value 
* formula

**Possible interaction with a formula**
*  user defined value -> empty ->user defined value -> [cells]
*  value  update -> user defined old value -> user defined new value [cells]
*  formula set -> empty ->formula[formulabar]
*  formula update -> old formula -> new formula [formulabar]
*  formula remove  -> formula -> user defined value [cells]



## formula implementation 




